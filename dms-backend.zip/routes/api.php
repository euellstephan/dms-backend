<?php

use Illuminate\Http\Request;
use Illuminate\Support\Facades\Route;
use App\Http\Controllers\AuthController;

use App\Http\Controllers\ResidenceController;
use App\Http\Controllers\OfficialController;

Route::get('/user', function (Request $request) {
    return $request->user();
})->middleware('auth:sanctum');


Route::post('register', [AuthController::class, 'register']);
Route::post('login', [AuthController::class, 'login']);


Route::middleware('auth:sanctum')->group(function () {

    Route::get('users', [AuthController::class, 'users']);
    Route::get('userProfile', [AuthController::class, 'userProfile']);
    Route::post('logout', [AuthController::class, 'logout']);


    Route::post('resident', [ResidenceController::class, 'store']);
    Route::get('residense', [ResidenceController::class, 'index']);
    Route::get('resident/{residence}', [ResidenceController::class, 'show']);
    Route::patch('resident/{residence}', [ResidenceController::class, 'update']);


    Route::get('officials', [OfficialController::class, 'index']);
    Route::post('official', [OfficialController::class, 'store']);
    Route::get('official/{official}', [OfficialController::class, 'show']);
    Route::patch('official/{official}', [OfficialController::class, 'update']);
    
});